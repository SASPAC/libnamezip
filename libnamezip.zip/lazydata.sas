filename P0218463 list;
 %put NOTE- ;
 %put NOTE: Data for package LibnameZip, version 0.0.1, license MIT; 
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-05-18T12:33:38; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- Write %nrstr(%%)helpPackage(LibnameZip) for the description;
 %put NOTE- ;
 %put NOTE- *** START ***; 

data _null_;
 length lazyData $ 32767; lazyData = lowcase(symget("lazyData"));
run;
%put NOTE- ;
%put NOTE: Data for package LibnameZip, version 0.0.1, license MIT;
%put NOTE- *** END ***;
/* lazydata.sas end */
