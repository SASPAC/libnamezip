/* File generated with help of SAS Packages Framework, version 20260515. */

/*** HELP START ***//*

### DESCRIPTION: ##############################################################

The `%procDelLibnameZip()` is a utility macro that 
emulates the `proc delete` behavior for the libanmeZip.

When executed the macro deletes: 
- the `ds.data` file from the ZIP, 
- the `ds.meta` file from the ZIP, and 
- the `lib.ds` view.

### SYNTAX: ###################################################################

The basic syntax is the following, the `<...>` means optional parameters:
~~~~~~~~~~~~~~~~~~~~~~~sas
%procDelLibnameZip(
  lib
, ds
)
~~~~~~~~~~~~~~~~~~~~~~~

**Arguments description**:

1. `lib`      - *Required.* Name of a library. Has to be 
                a valid SAS library name.

2. `ds`       - *Required.* Name of a data file. Has to be 
                a valid (one level) SAS data set name.

---

*//*** HELP END ***/

%macro procDelLibnameZip(lib,ds);
%put NOTE: &sysmacroname. START ---;
%if %sysfunc(exist(%superq(lib).libnameZip)) %then
  %do;
    %let ds = %sysfunc(compress(%superq(ds),_,kad));
    %if %length(&ds.)>32 %then 
      %do;
        %put WARNING: Data name truncated to 32 characters!;
        %let ds = %substr(&ds.,1,32);
      %end;
    %let ds = %sysfunc(lowcase(&ds.));
    %put NOTE: Deleting data %superq(ds) from libnameZip %superq(lib).;

    %local rc;

    %if %sysfunc(exist(&lib..&ds.,VIEW)) %then
      %do;
        %let rc = %sysfunc(dosubl(%nrstr(
          options ps=min nonotes nosource nosource2;

          data _null_;
            set &lib..libnameZip;
            length rctxt $ 2048;
            rc = filename("f", strip(path),"zip", "member='&ds..data'");
            put "INFO: Deleting data part of &lib..&ds.";
            rc = fdelete("f");
            rctxt = sysmsg();
            if rc then put (_ALL_) (=);
            rc = filename("f", strip(path),"zip", "member='&ds..meta'");
            put "INFO: Deleting metadata part of &lib..&ds.";
            rc = fdelete("f");
            rctxt = sysmsg();
            if rc then put (_ALL_) (=);
            rc = filename("f");
            put "INFO: Deleting view part of &lib..&ds.";
            stop;
          run; 
          proc delete data=&lib..&ds. (memtype=VIEW);
          run;
        )));
      %end;
  %end;
%else
  %do;
    %put WARNING: LibnameZip %superq(lib) not assigned! Exiting.;
  %end;
%put NOTE: &sysmacroname. END ---;
%mend procDelLibnameZip;

/*** HELP START ***//*

**EXAMPLE.** Create library `B` associated with the `R:/libnameZIP_B.zip` file. 
  Save the `work.LongVars` in `B` as `LongVars1`, `LongVars2`, and `LongVars3`.
  Compare `B.LongVars1` with `work.LongVars`; get `B.LongVars2` metadata;
  delete `LongVars3` from `B`.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~sas

%libnameZip(B,R:/libnameZIP_B.zip)


data LongVars;
  length a b c $ 32767;
  a = repeat("a",32766);
  b = repeat("b",32766);
  c = repeat("c",32766);
  do i = 1 to 1e3;
    output;
  end;
  format i ROMAN32.;
run;
%libnameZipData(B,LongVars1,work.LongVars);
%libnameZipData(B,LongVars2,work.LongVars);
%libnameZipData(B,LongVars3,work.LongVars);


proc compare
  base=work.LongVars(obs=123)
  comp=B.LongVars1(obs=123);
run;

proc contents data=B.LongVars2 varnum;
run;

%procDelLibnameZip(B,LongVars3)

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

---

*//*** HELP END ***/


/**###################################################################**/
/*                                                                     */
/*  Copyright Bartosz Jablonski, since 2026 onward.                    */
/*                                                                     */
/*  Code is under the MIT license. If you want - you can use it.       */
/*  But it comes "AS IS", with absolutely no warranty whatsoever.      */
/*  If you cause any damage or something - it will be your own fault.  */
/*  You've been warned! You are using it on your own risk.             */
/*                                                                     */
/*  However, if you decide to use it, you are obligated to mention     */
/*  the author Bartosz Jablonski (yabwon@gmail.com)                    */
/*                                                                     */
/**###################################################################**/

