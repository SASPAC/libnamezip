/* File generated with help of SAS Packages Framework, version 20260515. */

/*** HELP START ***//*

### DESCRIPTION: ##############################################################

The `%libnameZipClear()` is a "cleaning" macro that does the following:
- runs `proc datasets` to `kill` all views in the cleared library, and 
- de-assigns the library and the filename created by the `%libnameZip()` macro. 

### SYNTAX: ###################################################################

The basic syntax is the following, the `<...>` means optional parameters:
~~~~~~~~~~~~~~~~~~~~~~~sas
%libnameZipClear(
   lib
)
~~~~~~~~~~~~~~~~~~~~~~~

**Arguments description**:

1. `lib`      - *Required.* Name of a library created by 
                `%libnameZip()` macro.

---

*//*** HELP END ***/


%macro libnameZipClear(lib);
%if %sysfunc(exist(%superq(lib).libnameZip)) %then
  %do;
    proc datasets lib=&lib. kill NODETAILS NOLIST NOPRINT NOWARN;
    quit;
    filename &lib. clear;
    libname &lib. clear;
  %end;
%else
  %do;
    %put WARNING: LibnameZip %superq(lib) not assigned! Exiting.;
  %end;
%mend libnameZipClear;


/**###################################################################**/
/*                                                                     */
/*  Copyright Bartosz Jablonski, since 2026 onward.                    */
/*                                                                     */
/*  Code is under the MIT license. If you want - you can use it.       */
/*  But it comes "AS IS", with absolutely no warranty whatsoever.      */
/*  If you cause any damage or something - it will be your own fault.  */
/*  You've been warned! You are using it on your own risk.             */
/*                                                                     */
/*  However, if you decide to use it, you are obligated to mention     */
/*  the author Bartosz Jablonski (yabwon@gmail.com)                    */
/*                                                                     */
/**###################################################################**/

