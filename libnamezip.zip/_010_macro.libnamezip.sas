/* File generated with help of SAS Packages Framework, version 20260515. */

/*** HELP START ***//*

### DESCRIPTION: ##############################################################

The `%libnameZip()` is a "starting point" macro. 
It does the following:
- creates the `lib` library (located in a subdirectory 
  of session's WORK),

- generates the `lib.libnameZip` data set (used by other 
  components of the package),

- assigns the `lib` filename reference to the zip 
  file pointed by the `path` parameter,

- if the zip file contains any previously created data, 
  the macro creates views pointing to that data and 
  locates those views in the 'lib` library.

### SYNTAX: ###################################################################

The basic syntax is the following, the `<...>` means optional parameters:
~~~~~~~~~~~~~~~~~~~~~~~sas
%libnameZip(
  lib
, path
)
~~~~~~~~~~~~~~~~~~~~~~~

**Arguments description**:

1. `lib`      - *Required.* Name of a library. Has to be 
                a valid SAS library name.

2. `path`     - *Required.* A path to a ZIP file the will 
                be a data container for the libname.

---

*//*** HELP END ***/

%macro libnameZip(lib,path);
%put NOTE: &sysmacroname. START ---;
%let path = %sysfunc(dequote(%superq(path)));
%put INFO: Path Name is %superq(path);

%let lib = %sysfunc(compress(%superq(lib),_,kad));
%if %length(&lib.)>8 %then 
  %do;
    %put WARNING: Library name truncated to 8 characters!;
    %let lib = %substr(&lib.,1,8);
  %end;
%put INFO: Library Name is &lib;

%worklib(&lib.)

data &lib..libnameZip;
  length libName $ 8 path $ 4096;
  libName = "&lib.";
  path=symget('path');
  call symputX('path', quote(strip(path)), "L");
run;

filename &lib. ZIP &path.;
%put %sysfunc(sysmsg());
filename &lib. list;

/* if there are an files in the ZIP already assign them */
%local rc;
%let rc = %sysfunc(dosubl(%nrstr(
  options ps=min nonotes nosource nosource2;
  data _null_;
    length fid 8 lib $ 8 file $ 42 ds $ 32;
    lib = symget("lib");
    fid = dopen(lib);
    if 0<fid then
      do i = 1 to dnum(fid);
        file = dread(fid, i);
        /*put i= file=;*/
        ds = scan(file,1,".");
        if scan(file,2,".")="meta" then 
          call execute(
            'data ' !! catx(".",lib,ds) !! '/view=' !! catx(".",lib,ds) !! ';' !!
              '%include ' !! cats(lib) !! '(' !! cats(ds) !! '.meta);' !!
            'run;'
          );
      end;
    fid = dclose(fid);
    stop;
  run;
)));
%put NOTE: &sysmacroname. END ---;
%mend libnameZip;

/*** HELP START ***//*

### EXAMPLES AND USE CASES: ###################################################

**EXAMPLE.** Basic use case - Create library `A` associated with
  the `R:/libnameZIP_A.zip` file. Save the `work.cars` in `A` as `cars`
  Read `A.cars` back (two ways) and compare results.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~sas

%libnameZip(A,R:/libnameZIP_A.zip)


data work.cars;
  set sashelp.cars;
  do i = 1 to 1e3;
    output;
  end;
  label i = "Label for i";
run;
%libnameZipData(A,cars,work.cars);


data work.cars2;
  set %libnameZipSet(A,cars);
run;

data work.cars3;
  set A.cars; *works too!!;
run;


proc compare
  base=work.cars
  comp=work.cars2;
run;

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

---

*//*** HELP END ***/

/*** HELP START ***//*

**EXAMPLE.** Create library `B` associated with the `R:/libnameZIP_B.zip` file. 
  Save the `work.LongVars` in `B` as `LongVars1`, `LongVars2`, and `LongVars3`.
  Compare `B.LongVars1` with `work.LongVars`; get `B.LongVars2` metadata;
  delete `LongVars3` from `B`.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~sas

%libnameZip(B,R:/libnameZIP_B.zip)


data LongVars;
  length a b c $ 32767;
  a = repeat("a",32766);
  b = repeat("b",32766);
  c = repeat("c",32766);
  do i = 1 to 1e3;
    output;
  end;
  format i ROMAN32.;
run;
%libnameZipData(B,LongVars1,work.LongVars);
%libnameZipData(B,LongVars2,work.LongVars);
%libnameZipData(B,LongVars3,work.LongVars);


proc compare
  base=work.LongVars(obs=123)
  comp=B.LongVars1(obs=123);
run;

proc contents data=B.LongVars2 varnum;
run;

%procDelLibnameZip(B,LongVars3)

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

---

*//*** HELP END ***/

/*** HELP START ***//*

**EXAMPLE.** Create library `C` associated with the `R:/libnameZIP_C.zip` file. 
  Create library `D` associated with the `R:/libnameZIP_D.zip` file. 
  Save the `work.cars` in `C` under several different names. 
  Copy some files from `C` to `D`.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~sas

%libnameZip(C,R:/libnameZIP_C.zip)
%libnameZip(D,R:/libnameZIP_D.zip)


%libnameZipData(C,A1,sashelp.cars);
%libnameZipData(C,A2,sashelp.cars);
%libnameZipData(C,A3,sashelp.cars);
%libnameZipData(C,BX,sashelp.cars);
%libnameZipData(C,BY,sashelp.cars);
%libnameZipData(C,BZ,sashelp.cars);
%libnameZipData(C,CC,sashelp.cars);


%procCopyLibnameZip(in=C,out=D
,select=A1-A3 B:
,exclude=A2 BX
)


proc print data=%LibnameZipSet(C,BY)(obs=12);
run;

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

---

*//*** HELP END ***/

/*** HELP START ***//*

**EXAMPLE.** Create ZIP-libraries `E` and `F`. 
  Save `work.A` in `E` and `work.B` in `F`. Merge `E.a` and `F.b`.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~sas

%libnameZip(E,R:/libnameZIP_E.zip)
%libnameZip(F,R:/libnameZIP_F.zip)


data work.a(drop=x) work.b(drop=y);
  do i=1 to 2*1e5;
    x=10*i;
    y=100*i;
    output;
  end;
run;
%libnameZipData(E,a,work.a);
%libnameZipData(F,b,work.b);


data ab;
  merge E.a F.b end=end;
  by i;

  total + x+y;
  if end;
run;

proc print data=ab(obs=3);
run;

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

---

*//*** HELP END ***/


/**###################################################################**/
/*                                                                     */
/*  Copyright Bartosz Jablonski, since 2026 onward.                    */
/*                                                                     */
/*  Code is under the MIT license. If you want - you can use it.       */
/*  But it comes "AS IS", with absolutely no warranty whatsoever.      */
/*  If you cause any damage or something - it will be your own fault.  */
/*  You've been warned! You are using it on your own risk.             */
/*                                                                     */
/*  However, if you decide to use it, you are obligated to mention     */
/*  the author Bartosz Jablonski (yabwon@gmail.com)                    */
/*                                                                     */
/**###################################################################**/

