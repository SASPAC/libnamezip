/* File generated with help of SAS Packages Framework, version 20260515. */

/*** HELP START ***//*

### DESCRIPTION: ##############################################################

The `%libnameZipData()` creates the data file `ds` in 
the `lib` linameZip library using the `source` data set
as the input.

The macro creates two files inside the zip file affiliated
with the `lib` reference. Those files are: `ds.data` and
`ds.meta`. The first contains data from the `source`.
The second contains code that provides variables metadata
and reads in data from `ds.data`.

At the end of the process the `lib.ds` view is created.

Numeric variables are written with the `hex16.` format.
Character variables are written with the `$charW.` format.
The `W` parameter is set for each variable separately
based on its length.

During file creation the `recfm=` option is set to `f`, 
and `lrecl=` is calculated as: 

`(sum of char vars lengths) + (number of num vars) * 16`

Information about variables formats, informats, and 
labels are preserved.

### SYNTAX: ###################################################################

The basic syntax is the following, the `<...>` means optional parameters:
~~~~~~~~~~~~~~~~~~~~~~~sas
%libnameZipData(
  lib
, ds
, source
)
~~~~~~~~~~~~~~~~~~~~~~~

**Arguments description**:

1. `lib`      - *Required.* Name of a library. Has to be 
                a valid SAS library name.

2. `ds`       - *Required.* Name of a data file. Has to be 
                a valid (one level) SAS data set name.

3. `source`   - *Required.* A DATA set that is the 
                data source.

---

*//*** HELP END ***/

%macro libnameZipData(lib,ds,source); 
%if %sysfunc(exist(%superq(lib).libnameZip)) %then
  %do;
    %let ds = %sysfunc(compress(%superq(ds),_,kad));
    %if %length(&ds.)>32 %then 
      %do;
        %put WARNING: Data name truncated to 32 characters!;
        %let ds = %substr(&ds.,1,32);
      %end;
    %let ds = %sysfunc(lowcase(&ds.));
    %put NOTE: Createing data %superq(ds) in libnameZip %superq(lib).;

    %if NOT %sysfunc(exist(%superq(source))) %then
      %do;
        %put ERROR: The %superq(source) data set does not exist! Exiting.; 
        %return;
      %end;
    
    %local rc;
    %let rc = %sysfunc(dosubl(%nrstr(
    options ps=min nonotes nosource nosource2;
    data _nulL_;
      set &lib..libnameZip;
      call symputX ('path', quote(cats(path)), "L");
    run;

    /* filename &lib. ZIP &path.; */
    /*filename &lib. list;*/

    proc contents data=&source. varnum out=meta1 noprint;
    proc sort data=meta1; by varnum;
    /*proc print data=meta1;*/
    proc sort data=meta1 out=meta2; by npos;
    /*proc print data=meta2 label;*/
    run;

    data _null_;
      do until (_EM0_);
        set meta1 end=_EM0_;
        obs_len + (LENGTH+LENGTH*(TYPE=1));        
      end;

      file &lib.(&ds..meta);
      put "/* metadata for &ds. */";
      put 'infile &lib.'"(&ds..data) recfm=f lrecl=" obs_len ";";
      put "LENGTH";
        do until (_EM1_);
          set meta1 end=_EM1_;
          put NAME "$ " +(TYPE-3) LENGTH;
        end;
      put ";";


      call execute ("options notes; data _null_;");
      call execute ("  file &lib.(&ds..data) recfm=f lrecl=" !! cats(obs_len) !! ";");
      call execute ("  set &source.;");
      do until (_EM2_);
        set meta2 end=_EM2_;        

        put "input " NAME @@;
          if 1=type then
            put "hex16. " @@;
          else
            put "$char" LENGTH +(-1) ". " @@;
        put "@@;";

        if format   NE " " then 
          put "FORMAT " NAME FORMAT +(-1) FORMATL +(-1) "." FORMATD ";";

        if informat NE " " then 
          put "INFORMAT " NAME INFORMAT +(-1) INFORML +(-1) "." INFORMD ";";

        if label NE " " then
          do; 
            LENGTH LABELq $ 512;
            LABELq = quote(strip(LABEL));
            put "LABEL " NAME "=" LABELq ";";
          end;

        if 1=type then
            call execute(catX(" ","put",NAME,"hex16. @@;"));
          else
            call execute(catX(" ","put",NAME,cats("$char",LENGTH,"."),"@@;"));
      end;

      /*put "output;"
        / "_N_+1;" 
        / "if " NOBS "=_N_ then stop;";*/
      call execute ("run; options nonotes;");

      stop;
    run;

    data _null_; rc = sleep(1,0.1); run;
    data &lib..&ds. / view = &lib..&ds.;
      %include &lib.(&ds..meta) / source2;
    run;
    )));
    /*filename &lib. clear;*/

    %put NOTE- ---;
  %end;
%else
  %do;
    %put WARNING: LibnameZip %superq(lib) not assigned! Exiting.;
  %end;
%mend libnameZipData;

/*** HELP START ***//*

### EXAMPLES AND USE CASES: ###################################################

**EXAMPLE.** Basic use case - Create library `A` associated with
  the `R:/libnameZIP_A.zip` file. Save the `work.cars` in `A` as `cars`
  Read `A.cars` back (two ways) and compare results.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~sas

%libnameZip(A,R:/libnameZIP_A.zip)


data work.cars;
  set sashelp.cars;
  do i = 1 to 1e3;
    output;
  end;
  label i = "Label for i";
run;
%libnameZipData(A,cars,work.cars);


data work.cars2;
  set %libnameZipSet(A,cars);
run;

data work.cars3;
  set A.cars; *works too!!;
run;


proc compare
  base=work.cars
  comp=work.cars2;
run;

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

---

*//*** HELP END ***/

/*** HELP START ***//*

**EXAMPLE.** Create library `B` associated with the `R:/libnameZIP_B.zip` file. 
  Save the `work.LongVars` in `B` as `LongVars1`, `LongVars2`, and `LongVars3`.
  Compare `B.LongVars1` with `work.LongVars`; get `B.LongVars2` metadata;
  delete `LongVars3` from `B`.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~sas

%libnameZip(B,R:/libnameZIP_B.zip)


data LongVars;
  length a b c $ 32767;
  a = repeat("a",32766);
  b = repeat("b",32766);
  c = repeat("c",32766);
  do i = 1 to 1e3;
    output;
  end;
  format i ROMAN32.;
run;
%libnameZipData(B,LongVars1,work.LongVars);
%libnameZipData(B,LongVars2,work.LongVars);
%libnameZipData(B,LongVars3,work.LongVars);


proc compare
  base=work.LongVars(obs=123)
  comp=B.LongVars1(obs=123);
run;

proc contents data=B.LongVars2 varnum;
run;

%procDelLibnameZip(B,LongVars3)

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

---

*//*** HELP END ***/

/*** HELP START ***//*

**EXAMPLE.** Create library `C` associated with the `R:/libnameZIP_C.zip` file. 
  Create library `D` associated with the `R:/libnameZIP_D.zip` file. 
  Save the `work.cars` in `C` under several different names. 
  Copy some files from `C` to `D`.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~sas

%libnameZip(C,R:/libnameZIP_C.zip)
%libnameZip(D,R:/libnameZIP_D.zip)


%libnameZipData(C,A1,sashelp.cars);
%libnameZipData(C,A2,sashelp.cars);
%libnameZipData(C,A3,sashelp.cars);
%libnameZipData(C,BX,sashelp.cars);
%libnameZipData(C,BY,sashelp.cars);
%libnameZipData(C,BZ,sashelp.cars);
%libnameZipData(C,CC,sashelp.cars);


%procCopyLibnameZip(in=C,out=D
,select=A1-A3 B:
,exclude=A2 BX
)


proc print data=%LibnameZipSet(C,BY)(obs=12);
run;

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

---

*//*** HELP END ***/

/*** HELP START ***//*

**EXAMPLE.** Create ZIP-libraries `E` and `F`. 
  Save `work.A` in `E` and `work.B` in `F`. Merge `E.a` and `F.b`.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~sas

%libnameZip(E,R:/libnameZIP_E.zip)
%libnameZip(F,R:/libnameZIP_F.zip)


data work.a(drop=x) work.b(drop=y);
  do i=1 to 2*1e5;
    x=10*i;
    y=100*i;
    output;
  end;
run;
%libnameZipData(E,a,work.a);
%libnameZipData(F,b,work.b);


data ab;
  merge E.a F.b end=end;
  by i;

  total + x+y;
  if end;
run;

proc print data=ab(obs=3);
run;

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

---

*//*** HELP END ***/


/**###################################################################**/
/*                                                                     */
/*  Copyright Bartosz Jablonski, since 2026 onward.                    */
/*                                                                     */
/*  Code is under the MIT license. If you want - you can use it.       */
/*  But it comes "AS IS", with absolutely no warranty whatsoever.      */
/*  If you cause any damage or something - it will be your own fault.  */
/*  You've been warned! You are using it on your own risk.             */
/*                                                                     */
/*  However, if you decide to use it, you are obligated to mention     */
/*  the author Bartosz Jablonski (yabwon@gmail.com)                    */
/*                                                                     */
/**###################################################################**/

