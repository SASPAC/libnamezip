Type: Package
Package: LibnameZip
Title: Emulating ZIP engine for libname statement in SAS!
Version: 0.1.0
Author: Bartosz Jablonski (yabwon@gmail.com)
Maintainer: Bartosz Jablonski (yabwon@gmail.com)
License: MIT
Encoding: UTF8

ReqPackages: "BasePlus(3.1.4)"

DESCRIPTION START:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

The `LibnameZip` package is a bunch of macros design
to help emulate a ZIP-library engine in SAS.

[This is still an *experimental* phase,
 your feedback is most appreciated!]

Package allows seamlessly push back and forward data from
a SAS library to a compressed ZIP file. An interface is
set through SAS views.

So, under the hood the `DoSubL()` function, the `filename`
ZIP engine, and DATA step `view=` option are used heavily.

See examples for more details.

**Dependencies:**

The `BasePlus` package (version at least `(3.1.4)`)
is required for `LibnameZip` to work.

DESCRIPTION END:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
