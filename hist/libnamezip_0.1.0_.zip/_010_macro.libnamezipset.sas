/* File generated with help of SAS Packages Framework, version 20260515. */

/*** HELP START ***//*

### DESCRIPTION: ##############################################################

The `%libnameZipSet()` re-creates the `lib.ds` view created
by the `%libnameZipData()` or `%libnameZip()` macro.

The macro returns the view name, so it should be used either 
in the `SET` statement or int the `%PUT` statement, e.g.,

~~~~sas
SET %libnameZipSet();
~~~~

or

~~~~sas
%PUT %libnameZipSet();
~~~~

### SYNTAX: ###################################################################

The basic syntax is the following, the `<...>` means optional parameters:
~~~~~~~~~~~~~~~~~~~~~~~sas
%libnameZipSet(
  lib
, ds
,<q=>
)
~~~~~~~~~~~~~~~~~~~~~~~

**Arguments description**:

1. `lib`      - *Required.* Name of a library. Has to be 
                a valid SAS library name.

2. `ds`       - *Required.* Name of a data file. Has to be 
                a valid (one level) SAS data set name.

3. `q=0`      - *Optional.* "Q" stands for quiet. 
                When set to 1 suspends notes.
                

---

*//*** HELP END ***/

%macro libnameZipSet(lib,ds,q=0);
%local libnameZipSetViewName;
%if %sysfunc(exist(%superq(lib).libnameZip)) %then
  %do;
    %let ds = %sysfunc(compress(%superq(ds),_,kad));
    %if %length(&ds.)>32 %then 
      %do;
        %put WARNING: Data name truncated to 32 characters!;
        %let ds = %substr(&ds.,1,32);
      %end;
    %let ds = %sysfunc(lowcase(&ds.));
    %if %superq(q) NE 0 %then
      %put NOTE: Extracting data %superq(ds) from libnameZip %superq(lib).;

    %local rc;
    %if %sysfunc(exist(&lib..&ds.,DATA)) %then
      %do;
        %let rc = %sysfunc(dosubl(%nrstr(
          options ps=min nonotes nosource nosource2;  
          data _null_; rc = sleep(1,0.1); run;
          proc delete data=&lib..&ds. (memtype=VIEW);
          run;
        )));
      %end;

    %let rc = %sysfunc(dosubl(%nrstr(
      options ps=min nonotes source source2;
      data _null_; rc = sleep(1,0.1); run;
      data &lib..&ds. / view = &lib..&ds.;
        %include &lib.(&ds..meta) / source2;
      run;
    )));

    %let libnameZipSetViewName = &lib..&ds.;
  %end;
%else
  %do;
    %put WARNING: LibnameZip %superq(lib) not assigned! Exiting.;
  %end;

%do;&libnameZipSetViewName.%end;
%mend libnameZipSet;

/*** HELP START ***//*

### EXAMPLES AND USE CASES: ###################################################
*//*** HELP END ***/
/*** HELP START ***//*

**EXAMPLE.** Basic use case - Create library `A` associated with
  the `R:/libnameZIP_A.zip` file. Save the `work.cars` in `A` as `cars`
  Read `A.cars` back (two ways) and compare results.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~sas

%libnameZip(A,R:/libnameZIP_A.zip)


data work.cars;
  set sashelp.cars;
  do i = 1 to 1e3;
    output;
  end;
  label i = "Label for i";
run;
%libnameZipData(A,cars,work.cars);


data work.cars2;
  set %libnameZipSet(A,cars);
run;

data work.cars3;
  set A.cars; *works too!!;
run;


proc compare
  base=work.cars
  comp=work.cars2;
run;

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

---

*//*** HELP END ***/

/*** HELP START ***//*

**EXAMPLE.** Create library `C` associated with the `R:/libnameZIP_C.zip` file. 
  Create library `D` associated with the `R:/libnameZIP_D.zip` file. 
  Save the `work.cars` in `C` under several different names. 
  Copy some files from `C` to `D`.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~sas

%libnameZip(C,R:/libnameZIP_C.zip)
%libnameZip(D,R:/libnameZIP_D.zip)


%libnameZipData(C,A1,sashelp.cars);
%libnameZipData(C,A2,sashelp.cars);
%libnameZipData(C,A3,sashelp.cars);
%libnameZipData(C,BX,sashelp.cars);
%libnameZipData(C,BY,sashelp.cars);
%libnameZipData(C,BZ,sashelp.cars);
%libnameZipData(C,CC,sashelp.cars);


%procCopyLibnameZip(in=C,out=D
,select=A1-A3 B:
,exclude=A2 BX
)


proc print data=%LibnameZipSet(C,BY)(obs=12);
run;

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

---

*//*** HELP END ***/


/**###################################################################**/
/*                                                                     */
/*  Copyright Bartosz Jablonski, since 2026 onward.                    */
/*                                                                     */
/*  Code is under the MIT license. If you want - you can use it.       */
/*  But it comes "AS IS", with absolutely no warranty whatsoever.      */
/*  If you cause any damage or something - it will be your own fault.  */
/*  You've been warned! You are using it on your own risk.             */
/*                                                                     */
/*  However, if you decide to use it, you are obligated to mention     */
/*  the author Bartosz Jablonski (yabwon@gmail.com)                    */
/*                                                                     */
/**###################################################################**/

