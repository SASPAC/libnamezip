/* File generated with help of SAS Packages Framework, version 20260515. */

/*** HELP START ***//*

### DESCRIPTION: ##############################################################

The `%DataLibnameZip()` macro emulates behavior of the `DATA` statement.
It wraps around a DATA step code; adds `file` statement in the first line;
serches for `output` statement and replaces them with `link` to put statement. 

**Limitations**
- only a single data set can be created at a time,
- data set options on created datraset are ignored,
- only the `putlog` statement is allowed when writing to log,
- the `output` statement cannot contain data set name.

### SYNTAX: ###################################################################

The basic syntax is the following, the `<...>` means optional parameters:
~~~~~~~~~~~~~~~~~~~~~~~sas
%DataLibnameZip(lib.ds;
 <valid 4GL DATA step code>
)
~~~~~~~~~~~~~~~~~~~~~~~

The `lib.ds;` is the name of created data file.
Do not add the `DATA` keyword before it. The semicolon (`;`) 
is obligatory.

Do not add the `RUN;` statement at the bottom of the 4GL code.

**Arguments description**:

There are no arguments for this macro.

---

*//*** HELP END ***/

%macro DataLibnameZip()/parmbuff;
%local libds lib ds;
%let libds = %scan(%superq(syspbuff),1,%str(;),Q).; /* the . is to mark trailing spaces */
%let lib = %scan(%superq(libds),1,(.));
%let ds  = %scan(%superq(libds),2,(.));

%put #%superq(libds)#;

%if %sysfunc(exist(%superq(lib).libnameZip)) %then
%do;
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
%let ds = %sysfunc(compress(%superq(ds),_,kad));
%if %length(&ds.)>32 %then 
  %do;
    %put WARNING: Data name truncated to 32 characters!;
    %let ds = %substr(&ds.,1,32);
  %end;
%let ds = %sysfunc(lowcase(&ds.));
/*%put NOTE: Createing data %superq(ds) in libnameZip %superq(lib).;*/


/*%put &syspbuff.;*/
%local code rc meta2 meta2Nobs i statementN obs_len impliciteOutput;

%let libds=%sysevalf(%length(%superq(libds))-1);
%let code = (%substr(%superq(syspbuff),%eval(&libds.+2)); /* there is the openning "(" */

/*
%put %superq(libds);
%put %superq(lib);
%put %superq(ds);
%put %superq(code);
*/

%if %sysfunc(exist(&lib..&ds.,VIEW)) %then
  %do;
    %let rc = %sysfunc(dosubl(%nrstr(
      options ps=min nonotes nosource nosource2;  
      data _null_; rc = sleep(1,0.1); run;
      proc delete data=&lib..&ds. (memtype=VIEW);
      run;
    )));
  %end;

%let meta2 = WORK.___%sysfunc(datetime(),hex16.)_meta2X;
%let meta2Nobs = 0;
%let rc = %sysfunc(dosubl(%nrstr(
options ps=min nonotes nosource nosource2;
data &lib..&ds.;stop;
%substr(&code., 2, %length(&code.)-2)
proc contents data=&lib..&ds. varnum out=&meta2. noprint;
proc sort data=&meta2.; by npos;
run;
%let meta2Nobs=&SYSNOBS.;
)));
/*%put &=meta2Nobs.;*/

%libnameZipData(&lib.,&ds.,&lib..&ds.,suppressView=1,metaDataonly=1)

%let rc = %sysfunc(dosubl(%nrstr(
options ps=min nonotes nosource nosource2;
proc delete data=&lib..&ds.;
run;
data &lib..&ds. / view = &lib..&ds.;
  %include &lib.(&ds..meta) / source2;
run;
)));

%let statementN=0;
%do i = 1 %to &meta2Nobs.;
  %local statement&i.;
%end;
%let rc = %sysfunc(dosubl(%nrstr(
options ps=min nonotes nosource nosource2;
data _nuLL_;
  set &meta2. end=_E_;
  length statement $ 128;
  if 1=type then
    statement = catX(" ","put",NAME,"hex16. @@;");
  else
    statement = catX(" ","put",NAME,cats("$char",LENGTH,"."),"@@;");
  call symputX(cats("statement",_N_),statement,"L");

  obs_len + (LENGTH+LENGTH*(TYPE=1));
  if _E_;
  call symputX(cats("statementN"),_N_,"L");
  call symputX(cats("obs_len"),obs_len,"L");
run;
proc delete data=&meta2.;
run;
)));

/* check if OUTPUT is present */
%let impliciteOutput = %sysfunc(PRXMATCH(%str(/output\s*;/i), %superq(code)));
/* replace every OUTPUT with GOTO */
%let code = %sysfunc(PRXCHANGE(%str(s/output\s*;/LINK ______outputReplaced;/i), -1, %superq(code)));

/* print the code */
%put %superq(code);

data _null_;
file &lib.(&ds..data) recfm=f lrecl=&obs_len.;
%substr(&code., 2, %length(&code.)-2)

%if 0=%eval(&impliciteOutput.+0) %then 
  %do; LINK ______outputReplaced; %end;
return;
______outputReplaced:

  %do i = 1 %to &statementN.;
    &&statement&i..
  %end;

return;
run;
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
%put NOTE- ---;
%end;
%else
  %do;
    %put WARNING: LibnameZip %superq(lib) not assigned! Exiting.;
  %end;
%mend DataLibnameZip;

/*** HELP START ***//*

### EXAMPLES AND USE CASES: ###################################################
*//*** HELP END ***/
/*** HELP START ***//*

**EXAMPLE.** Create library `G` associated with the `R:/libnameZIP_G.zip` file. 
  Write DATA step result directly to the ZIP file. The `run;` statement after 
  the macro call is optional.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~sas

%libnameZip(G,R:/libnameZIP_G.zip)


%DataLibnameZip(G.cars;
  set sashelp.cars;
  by origin notsorted;
  drop invoice mpg:;
  if last.origin then output ;
)


%DataLibnameZip(G.square;
  array x[100] (1:100);
  do i = 1 to 100;
    output;
  end;
  drop i;
)
run;

%DataLibnameZip(G.class;
  set 
    sashelp.class
    sashelp.class
    sashelp.class
    sashelp.class
    sashelp.class
  ;
)
run;

proc contents data=G.cars;
run;

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

---

*//*** HELP END ***/


/**###################################################################**/
/*                                                                     */
/*  Copyright Bartosz Jablonski, since 2026 onward.                    */
/*                                                                     */
/*  Code is under the MIT license. If you want - you can use it.       */
/*  But it comes "AS IS", with absolutely no warranty whatsoever.      */
/*  If you cause any damage or something - it will be your own fault.  */
/*  You've been warned! You are using it on your own risk.             */
/*                                                                     */
/*  However, if you decide to use it, you are obligated to mention     */
/*  the author Bartosz Jablonski (yabwon@gmail.com)                    */
/*                                                                     */
/**###################################################################**/

