/* File generated with help of SAS Packages Framework, version 20260617. */

/*** HELP START ***//*

### DESCRIPTION: ##############################################################

The `%procCopyLibnameZip()` is a utility macro that 
emulates the `proc copy` behavior for two libanmeZip,
i.e., makes copying data between ZIPs easier.

### SYNTAX: ###################################################################

The basic syntax is the following, the `<...>` means optional parameters:
~~~~~~~~~~~~~~~~~~~~~~~sas
%procDelLibnameZip(
  in=
, out=
<,select=>
<,exclude=>
)
~~~~~~~~~~~~~~~~~~~~~~~

**Arguments description**:

* `in=`      - *Required.* Name of the input libnameZip library. 
               Has to be a valid SAS library name.

* `out=`     - *Required.* Name of the output libnameZip library. 
               Has to be a valid SAS library name.

* `select=`  - *Optional.* A space separated list of data file 
               names *selected* for copy. By default all files 
               are copied.

* `exclude=` - *Optional.* A space separated list of data file 
               names *excluded* from copy. By default the 
               list is empty.

---

*//*** HELP END ***/

%macro procCopyLibnameZip(
 in=
,out=
,select=_ALL_
,exclude=
);
%put NOTE: &sysmacroname. START ---;
%let in = %sysfunc(compress(%superq(in),_,kad));
%if %length(&in.)>8 %then 
  %do;
    %put WARNING: Library name truncated to 8 characters!;
    %let in = %substr(&in.,1,8);
  %end;
%put INFO: In-Library Name is &in.;

%let out = %sysfunc(compress(%superq(out),_,kad));
%if %length(&out.)>8 %then 
  %do;
    %put WARNING: Library name truncated to 8 characters!;
    %let out = %substr(&out.,1,8);
  %end;
%put INFO: Out-Library Name is &out.;

%if NOT %sysfunc(exist(&in..libnameZip)) %then
  %do;
    %put ERROR: In-Library &in. does not exist! Exiting.;
    %return;
  %end;

%if NOT %sysfunc(exist(&out..libnameZip)) %then
  %do;
    %put ERROR: Out-Library &out. does not exist! Exiting.;
    %return;
  %end;

%local rc selectList;
%let selectList = WORK.___%sysfunc(datetime(),hex16.)_selectList;
%let rc = %sysfunc(dosubl(%nrstr(
options ps=min msglevel=N nonotes nosource nosource2 DKRICOND=NOWARNING DKROCOND=NOWARNING;
data _nulL_;
  set &in..libnameZip;
  INpath=path;
  set &out..libnameZip;
  OUTpath=path;

  declare hash IN(ordered:"A");
  IN.defineKey('ds');
  IN.defineDone();
 
  if INpath = OUTpath then
    do;
      put "WARNING: Path to &in. and &out. are the same. Exiting.";
      IN.output(dataset:"&selectList.");
      stop;
    end;

  length INlib OUTlib $ 8 file $ 42 ds $ 32;
  rci = filename(INlib, strip(INpath), "ZIP");
  rco = filename(OUTlib,strip(OUTpath),"ZIP");

  fid = dopen(INlib);
  if 0<fid then
    do i = 1 to dnum(fid);      
      file = dread(fid, i);
      ds = scan(file,1,".");
      rc = IN.add();
      /*put i= file=;*/
    end;
  IN.output(dataset:"&selectList.");

call execute('proc transpose data=&selectList. out=&selectList.(drop=_NAME_);');
call execute('id ds; run;');
call execute('proc transpose data=&selectList.(obs=0');
call execute('drop=&exclude.');
call execute('keep=&select.');
call execute(') out=&selectList.(rename=(_NAME_=ds));');
call execute('var _ALL_; run;');
stop;
run;

data _nulL_;
  if nobs;
  set &in..libnameZip;
  INpath=path;
  set &out..libnameZip;
  OUTpath=path;

  length INlib OUTlib $ 8 ds $ 32 member $ 64 rcitxt rcotxt rcctxt $ 1024;   
  do until (_E_); 
    set &selectList. end=_E_ nobs=nobs;

    put "INFO: Copying " ds "from &in. to &out.";  
    do type = ".meta",".data";
      member = cats("member='",ds,type,"' lrecl=1 recfm=n");
      rci = filename(INlib, strip(INpath), "ZIP",member);
      rcitxt = sysmsg();
      rco = filename(OUTlib,strip(OUTpath),"ZIP",member);
      rcotxt = sysmsg();

      if NOT (rci + rco) then
        do;
          rcc = fcopy(INlib,OUTlib);
          rcctxt = sysmsg();
          if rcc then put rcc ;
          rci = filename(INlib);
          rco = filename(OUTlib);
        end;
      else
        put rcitxt / rcotxt;
    end;
  end;
stop;
run; 
proc delete data=&selectList.;
run;
)));
%put NOTE: &sysmacroname. END ---;
%mend procCopyLibnameZip;

/*** HELP START ***//*

### EXAMPLES AND USE CASES: ###################################################
*//*** HELP END ***/
/*** HELP START ***//*

**EXAMPLE.** Create library `C` associated with the `R:/libnameZIP_C.zip` file. 
  Create library `D` associated with the `R:/libnameZIP_D.zip` file. 
  Save the `work.cars` in `C` under several different names. 
  Copy some files from `C` to `D`.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~sas

%libnameZip(C,R:/libnameZIP_C.zip)
%libnameZip(D,R:/libnameZIP_D.zip)


%libnameZipData(C,A1,sashelp.cars);
%libnameZipData(C,A2,sashelp.cars);
%libnameZipData(C,A3,sashelp.cars);
%libnameZipData(C,BX,sashelp.cars);
%libnameZipData(C,BY,sashelp.cars);
%libnameZipData(C,BZ,sashelp.cars);
%libnameZipData(C,CC,sashelp.cars);


%procCopyLibnameZip(in=C,out=D
,select=A1-A3 B:
,exclude=A2 BX
)


proc print data=%LibnameZipSet(C,BY)(obs=12);
run;

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

---

*//*** HELP END ***/


/**###################################################################**/
/*                                                                     */
/*  Copyright Bartosz Jablonski, since 2026 onward.                    */
/*                                                                     */
/*  Code is under the MIT license. If you want - you can use it.       */
/*  But it comes "AS IS", with absolutely no warranty whatsoever.      */
/*  If you cause any damage or something - it will be your own fault.  */
/*  You've been warned! You are using it on your own risk.             */
/*                                                                     */
/*  However, if you decide to use it, you are obligated to mention     */
/*  the author Bartosz Jablonski (yabwon@gmail.com)                    */
/*                                                                     */
/**###################################################################**/

