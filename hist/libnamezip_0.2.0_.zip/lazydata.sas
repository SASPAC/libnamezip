filename P0218463 list;
 %put NOTE- ;
 %put NOTE: Data for package LibnameZip, version 0.2.0, license MIT; 
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-06-21T11:16:49; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- Write %nrstr(%%)helpPackage(LibnameZip) for the description;
 %put NOTE- ;
 %put NOTE- *** START ***; 

data _null_;
 length lazyData $ 32767; lazyData = lowcase(symget("lazyData"));
run;
%put NOTE- ;
%put NOTE: Data for package LibnameZip, version 0.2.0, license MIT;
%put NOTE- *** END ***;
/* lazydata.sas end */
